# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

class OmHospitalOdoo(http.Controller):
         # simple controller create
    @http.route('/library/book/rent/', website=True, auth='public')

    def library_book(self, **kw):

         # return "thank you for watching"
        book = request.env['book.book'].sudo().search([])
        print('books rent ....', book)
        return http.request.render("library_management.book_page", {
            'books': book
        })



#     @http.route('/om_hospital/om_hospital/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('om_hospital.listing', {
#             'root': '/om_hospital/om_hospital',
#             'objects': http.request.env['om_hospital.om_hospital'].search([]),
#         })

#     @http.route('/om_hospital/om_hospital/objects/<model("om_hospital.om_hospital"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('om_hospital.object', {
#             'object': obj
#         })
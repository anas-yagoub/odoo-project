# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
class wibsiteDirections(http.Controller):
    @http.route('/productos/<model("product.template"):product>', website=True, auth='public')
    def fun_product(self, product):
            return http.request.render('library_management.product',  {
                "product": product
            })


# @http.route('/contactus', website=True, auth='public')
    # def contacto_redirect(self, **kw):
    #     return request.render("/contacto")
    #
    # @http.route('/contacto', website=True, auth='public')
    # def contacto_redirect(self):
    #     return http.request.render("website.contactus",{})




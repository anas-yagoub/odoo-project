# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

class OmHospital(http.Controller):
     #simple controller create
    @http.route('/library/book/', website=True ,auth='public' )

        # simple controller create
    def library_book_rent(self, **kw):
         # return "thank you for watching"
         order = request.env['sale.order'].sudo().search([])
         print('books rent ....', order)
         return http.request.render("library_management.sale_details_page", {
             'orders': order
         })

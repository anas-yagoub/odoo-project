from odoo import models, fields, api, _
class customer_inherit(models.Model):
    _inherit = 'res.partner'


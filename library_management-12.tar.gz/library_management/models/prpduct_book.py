from odoo import models, fields, api, _
class product_inherit(models.Model):
    _inherit = 'product.template'
    author = fields.Char(string="Author")

from odoo import models, fields, api, _
from datetime import timedelta

class sale_inherit(models.Model):
    _inherit = 'sale.order'
    end_rent =fields.Date(string="End Rend",  store=True,
        compute='_get_end_date', inverse='_set_end_date')
    duration = fields.Float(digits=(6, 2), help="Duration in days")
    start_date = fields.Date(default=fields.Date.today)
    instructor_id = fields.Many2one('res.partner', string="Instructor")

    @api.depends('start_date', 'duration')
    def _get_end_date(self):
        for r in self:
            if not (r.start_date and r.duration):
                r.end_rent = r.start_date
                continue

            # Add duration to start_date, but: Monday + 5 days = Saturday, so
            # subtract one second to get on Friday instead
            duration = timedelta(days=r.duration, seconds=-1)
            r.end_rent = r.start_date + duration

    def _set_end_date(self):
        for r in self:
            if not (r.start_date and r.end_rent):
                continue

            # Compute the difference between dates, but: Friday - Monday = 4 days,
            # so add one day to get 5 days instead
            r.duration = (r.end_rent - r.start_date).days + 0
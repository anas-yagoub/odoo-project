from odoo import models, fields, api,_

class req_purcha_inherit(models.Model):
   _inherit = 'purchase.order'








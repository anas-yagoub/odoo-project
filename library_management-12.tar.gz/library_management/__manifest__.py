# -*- coding: utf-8 -*-
{
    'name': "Library Management",

    'summary': """
module to manageing the library""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','purchase','sale','board'],

    # always loaded
    'data': [
        #'security/ir.model.access.csv',
        'wizards/purchase_report_wizard.xml',
        'wizards/sale_report_wizard.xml',
        'reports/purchase_report_vendor.xml',
        'reports/sales_report_customer.xml',
        'reports/purchase_reports.xml',
        'reports/sales_report.xml',
        'views/customer.xml',
        'views/product_book.xml',
        'views/rquest_for_quotation.xml',
        'views/sale_order.xml',
        'views/sele_book.xml',
        'views/dashboard.xml',

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
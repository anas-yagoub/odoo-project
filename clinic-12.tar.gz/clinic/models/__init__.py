# -*- coding: utf-8 -*-

from . import clinic_patient
from . import clinic_doctor
from . import doctor_specialty
from . import clinic_booking
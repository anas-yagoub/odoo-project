# -*- coding: utf-8 -*-
from odoo import models, fields, api,_

class HospitalPatient(models.Model):
    _name = 'hospital.patient'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Patient Record"
    name = fields.Char(string="Name", required=True)
    notes = fields.Text(string="Notes")
    age_name = fields.Integer(string="Age", required=True)
    image = fields.Binary(string="Image")
    name_scq = fields.Char(string="Order Reference", required=True,copy= False ,readonly=True,
                           index=True,default=lambda self:_('New'))
    @api.model
    def create(self, vals):
        if vals.get('name_scq', _('New')) == _('New'):
                vals['name_scq'] = self.env['ir.sequence'].next_by_code('hospital.patient.sequence') or _('New')
        result = super(HospitalPatient, self).create(vals)
        return result
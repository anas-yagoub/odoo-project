from odoo import models, fields, api,_

class DoctorSpecialty(models.Model):
    _name = "doctor.specialty"
    _description = "Doctor Specialty"

    name = fields.Char(string="Name")

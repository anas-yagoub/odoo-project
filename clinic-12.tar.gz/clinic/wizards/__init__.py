from . import clinic_booking_wizard_report
from . import wizard_report_clinic
from . import test_wizard


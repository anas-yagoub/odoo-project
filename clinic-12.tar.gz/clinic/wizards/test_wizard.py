from odoo import models, fields, api, _
class TestReport(models.TransientModel):
    _name = 'test.clinic.report.wizard'
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    booking_ids = fields.Many2one('clinic.booking', string='Doctors', required=True)


    def print_test_report(self):
        purchase_order = self.env['clinic.booking'].search([])
        purchase_order_groupby_dict = {}
        for doctor in self.booking_ids:
            filtered_purchase_order = list(filter(lambda x: x.booking_ids == doctor, purchase_order))
            print('filtered_sale_order ===', filtered_purchase_order)
            filtered_by_date = list(filter(lambda x: x.date >= self.start_date and x.date <= self.end_date,
                                           filtered_purchase_order))
            final_dist = {}
            for doctor in purchase_order_groupby_dict.keys():
                purchase_data = []
                for order in purchase_order_groupby_dict[doctor]:
                    temp_data = []
                    temp_data.append(order.doctor_id.name)
                    temp_data.append(order.patient_id.name)
                    temp_data.append(order.date)
                    temp_data.append(order.meeting_date)
                    temp_data.append(order.state)
                    purchase_data.append(temp_data)
                final_dist[doctor] = purchase_data
            datas = {
                'ids': self,
                'model': 'test.clinic.report.wizard',
                'form': final_dist,
                'start_date': self.start_date,
                'end_date': self.end_date
            }
            print('datas:', datas)
            return self.env.ref('clinic.test_report_action').report_action([], data=datas)

from odoo import models, fields, api, _
class PurchaseReportVendor(models.TransientModel):
    _name = 'patient.clinic.report.wizard'
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    state = fields.Selection([('draft', 'Draft'), ('wait_d_meeting', 'Wait Doctor Meeting'),
                              ('stay_on_ward', 'Stay On Ward'), ('medical_bill', 'Medical Bill')], string='State')
    doctor_id = fields.Many2one('clinic.doctor', string='Doctors', required=True)

    def print_vendor_wise_purchase_report(self):
        purchase_order = self.env['clinic.booking'].search([])
        purchase_order_groupby_dict = {}
        for doctor in self.doctor_id:
            filtered_purchase_order = list(filter(lambda x: x.doctor_id == doctor, purchase_order))
            print('filtered_sale_order ===', filtered_purchase_order)
            filtered_by_date = list(filter(lambda x: x.date >= self.start_date and x.date <= self.end_date,
                                           filtered_purchase_order))
            print('State:', self.state)
            filtered_by_state = list(filter(lambda x: x.state == self.state or self.state == False, filtered_by_date))
            purchase_order_groupby_dict[doctor.name] = filtered_by_state

            final_dist = {}
            for doctor in purchase_order_groupby_dict.keys():
                purchase_data = []
                for order in purchase_order_groupby_dict[doctor]:
                    order_state = self.get_state_display_value(order.state)
                    temp_data = []
                    temp_data.append(order.doctor_id.name)
                    temp_data.append(order.patient_id.name)
                    temp_data.append(order.date)
                    temp_data.append(order.meeting_date)
                    temp_data.append(order.state)
                    purchase_data.append(temp_data)
                final_dist[doctor] = purchase_data
            datas = {
                'ids': self,
                'model': 'patient.clinic.report.wizard',
                'form': final_dist,
                'start_date': self.start_date,
                'end_date': self.end_date
            }
            print('datas:', datas)
            return self.env.ref('clinic.report_clinic_patient').report_action([], data=datas)
    def get_state_display_value(self, order_state):
        if order_state == 'draft':
            order_state = 'RFQ'
        elif order_state == 'Sales':
            order_state = 'Sales Order'
        elif order_state == 'sent':
            order_state = 'RFQ Sent'
        elif order_state == 'done':
            order_state = 'Done'
        elif order_state == 'cancel':
            order_state = 'Cancelled'
        return order_state


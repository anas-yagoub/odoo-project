
from odoo import fields, models, api

class ClinicBookingReportDetails(models.AbstractModel):
    _name = "report.clinic.booking_report_temp"
    @api.model
    def get_report_values(self, docids, data=None):
        booking_ids = self.env['clinic.booking'].search([('id', '=', data['booking_ids'])])
        docids = docids
        return {
            'data': booking_ids
            }
from . import clinic_report_wiz
from . import wizard_report_clinic
from . import test_booking
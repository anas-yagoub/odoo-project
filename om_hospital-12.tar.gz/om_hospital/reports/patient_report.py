from odoo import api, fields, models, _
from datetime import date
class PatientReport(models.TransientModel):
    _name = 'patient.report'
    _description = "Patient Report"

    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')

    @api.multi
    def print_report(self):
        data = {}
        data['form'] = self.read(['start_date','end_date'])
        return self._print_report(data)

    def _print_report(self, data):
        return self.env.ref('om_hospital.action_medicine_expiry_report').report_action(self, data=data, config=False)
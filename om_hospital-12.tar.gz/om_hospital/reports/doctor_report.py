from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT , DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT
from datetime import datetime
class DoctorReport(models.TransientModel):
    _name = 'hospital.doctor'
    _description = "Doctor Report"
    start_date = fields.Date(string='Start Date')
    end_date = fields.Date(string='End Date')


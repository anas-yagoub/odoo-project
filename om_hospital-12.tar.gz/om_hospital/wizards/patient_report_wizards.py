from odoo import models, fields, api
class PatientReportWizard(models.TransientModel):
    _name = 'patient.report.wizard'
    _description = 'Patient Report'

    from_date = fields.Date('From', default=fields.Date.today())
    to_date = fields.Date('To', default=fields.Date.today())

    def get_report(self):
        data = {
            'ids': self.ids,
            'model': self._name,
            'form': {
                'from_date': fields.Date.from_string(self.from_date),
                'to_date': fields.Date.from_string(self.to_date),
            },
        }

        return self.env.ref('om_hospital.patient_reports').report_action(self, data=data)


class PatientReport(models.AbstractModel):
    _name = 'report.patient'
    @api.model
    def get_report_values(self, docids, data=None):
        from_date = data['form']['from_date']
        to_date = data['form']['to_date']

        docs = self.env['hospital.patient'].search([('date', '>=', from_date), ('date', '<=', to_date)])

        return {
            'doc_ids': data['ids'],
            'doc_model': data['model'],
            'from_date': from_date,
            'to_date': to_date,
            'docs': docs,
        }
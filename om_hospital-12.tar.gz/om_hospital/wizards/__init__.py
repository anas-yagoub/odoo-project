from . import create_appointment
from . import doctor_wizards
from . import patient_report_wizards


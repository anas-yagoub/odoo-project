from odoo import models, fields, api, _
from datetime import datetime
class DoctorWizards(models.TransientModel):
    _name = 'doctor.report.wizard'
    from_date = fields.Date(string="From", default=fields.Date.today())
    to_date = fields.Date(string="To", default=fields.Date.today())
    def get_report(self):
        data = {
            'ids': self.ids,
            'model': self._name,
            'form': {
                'from_date': fields.Date.from_string(self.from_date),
                'to_date': fields.Date.from_string(self.to_date),
            },
        }
        return self.env.ref('om_hospital.report_doctor').report_action(self, data=data)

class DoctorReport(models.AbstractModel):
    _name = 'report.doctor_template'
    @api.model
    def get_report_values(self, docids, data=None):
        from_date = data['form']['from_date']
        to_date = data['form']['to_date']
        docs = self.env['hospital.doctor'].search([('date', '>=', from_date), ('date', '<=', to_date)])
        return {
            'doc_ids': data['ids'],
            'doc_model': data['model'],
            'from_date': from_date,
             'to_date': to_date,
            'docs': docs,
        }




# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
class HospitalDoctor(models.Model):
    _name = 'hospital.doctor'
    _description = "Doctor"
    _order = "id desc"
    name = fields.Char(string="doctor ID", required=True,copy= False ,readonly=True,
                           index=True,default=lambda self:_('New'))
    doctor_name = fields.Char(string="Name", required=True)
    gender = fields.Selection([
        ('male', 'Male'),
        ('fe_male', 'Female'),
    ], string="Gender")
    appointment_ids = fields.Many2many('hospital.appointment', 'hospital_patient_rel', 'doctor_id_rec', 'appointment_id',
                                  string='Appointments')
    state = fields.Selection([
        ('draft','Draft'),
        ('confirm','Confirm'),
        ('done','Done'),
        ('cancel','canceled'),
    ],string='Status',readonly=True,default='draft')

    def action_confirm(self):
        for rec in self:
            rec.state='confirm'

    def action_done(self):
        for rec in self:
            rec.state='done'




    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('hospital.doctor.sequence') or _('New')
        result = super(HospitalDoctor, self).create(vals)
        return result
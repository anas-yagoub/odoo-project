# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class HospitalAppointment(models.Model):
    _name = 'hospital.appointment'
    _description = "Appointment"
    _order = "id desc"
    name = fields.Char(string="Appointment ID", required=True,copy= False ,readonly=True,
                           index=True,default=lambda self:_('New'))
    patient_id = fields.Many2one('hospital.patient',string="Patient",required=True )
    patient_age = fields.Integer(string="Age",related='patient_id.patient_age', required=True)
    doctor  = fields.Text(string="Note")
    pharmacy  = fields.Text(string="Note")
    appointment_lines = fields.One2many('hospital.appointment.lines', 'appointment_id', string='Appointment Lines')
    appointment_date = fields.Date(string="Date",required=True)
    appointment_date_end = fields.Date(string='End Date')
    appointment_datetime = fields.Datetime(string='Date Time')
    amount = fields.Float(string="Total Amount")
    state = fields.Selection([
        ('draft','Draft'),
        ('confirm','Confirm'),
        ('done','Done'),
        ('cancel','canceled'),
    ],string='Status',readonly=True,default='draft')

    def action_confirm(self):
        for rec in self:
           rec.state='confirm'
    def action_done(self):
        for rec in self:
            rec.state='done'


    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('hospital.appointment.sequence') or _('New')
        result = super(HospitalAppointment, self).create(vals)
        return result


class HospitalAppointmentLine(models.Model):
    _name = 'hospital.appointment.lines'
    _description = "Appointment Lines"
    medicine =fields.Char(string='Medicine',required="True")
    appointment_id =fields.Many2one('hospital.appointment',string='Appointment Id')
    quantity =fields.Integer(string='Quantity')
    note  = fields.Text(string="Note")

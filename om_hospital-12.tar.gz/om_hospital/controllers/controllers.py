# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request


class OmHospital(http.Controller):
     #simple controller create
    @http.route('/hospital/doctor/', website=True ,auth='public' )
    def hospital_patient(self, **kw):

        #return "thank you for watching"
        patients = request.env['hospital.patient'].sudo().search([])
        print('patients ....',patients)
        return http.request.render("om_hospital.patient_page", {
            'patients':patients
        })

#     @http.route('/om_hospital/om_hospital/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('om_hospital.listing', {
#             'root': '/om_hospital/om_hospital',
#             'objects': http.request.env['om_hospital.om_hospital'].search([]),
#         })

#     @http.route('/om_hospital/om_hospital/objects/<model("om_hospital.om_hospital"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('om_hospital.object', {
#             'object': obj
#         })